import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

main() async {
  await GetStorage.init();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int counter = 0;
  final box = GetStorage();

  @override
  void initState() {
    super.initState();
    _loadCounter();
  }

  void _loadCounter() {
    counter = box.read('count') ?? 0;
  }

  void tambah() {
    setState(() {
      counter++;
      box.write('count', counter);
    });
  }

  void kurang() {
    setState(() {
      counter--;
      box.write('count', counter);
    });
  }

  @override
  Widget build(BuildContext context) {
    box.writeIfNull('count', 0);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        appBarTheme: const AppBarTheme(color: Colors.black),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text(
            "Belajar Get Storage Feri ",
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const Text(
                "Feri Angka Saat ini :",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 29,
                ),
              ),
              Text(
                '${box.read('count')}',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                      onPressed: () {
                        setState(() {
                          (counter != 0) ? kurang() : null;
                        });
                      },
                      child: const Icon(Icons.remove)),
                  ElevatedButton(
                      onPressed: () {
                        tambah();
                      },
                      child: const Icon(Icons.add)),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
