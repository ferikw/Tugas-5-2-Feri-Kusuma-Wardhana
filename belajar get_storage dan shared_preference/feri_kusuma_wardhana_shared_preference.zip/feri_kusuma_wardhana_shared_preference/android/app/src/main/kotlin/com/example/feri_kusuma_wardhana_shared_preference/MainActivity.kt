package com.example.feri_kusuma_wardhana_shared_preference

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
